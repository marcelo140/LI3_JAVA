public class InvalidPageException extends Exception {

	public InvalidPageException(String msg) {
		super(msg);
	}
}
