public class InvalidBranchException extends Exception {

	public InvalidBranchException(String msg) {
		super(msg);
	}
}
