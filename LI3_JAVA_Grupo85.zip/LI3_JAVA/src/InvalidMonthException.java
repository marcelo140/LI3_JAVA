public class InvalidMonthException extends Exception {

	public InvalidMonthException(String msg) {
		super(msg);
	}
}
