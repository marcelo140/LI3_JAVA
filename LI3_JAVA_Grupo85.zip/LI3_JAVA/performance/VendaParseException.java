public class VendaParseException extends Exception {
	VendaParseException(String msg) {
		super(msg);
	}
}
